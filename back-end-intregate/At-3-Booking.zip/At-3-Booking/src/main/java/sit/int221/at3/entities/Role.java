package sit.int221.at3.entities;

public enum Role {
    student,lecturer,admin,guest;
}
