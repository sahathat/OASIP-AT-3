package sit.int221.at3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class At3BookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
