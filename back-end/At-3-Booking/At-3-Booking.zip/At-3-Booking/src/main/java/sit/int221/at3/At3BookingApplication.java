package sit.int221.at3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class At3BookingApplication {
    public static void main(String[] args) {
        SpringApplication.run(At3BookingApplication.class, args);
    }
}